﻿using DataContract.Dto;
using DataLib.Context;
using DataLib.Entity;
using Microsoft.Extensions.Configuration;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.Security.Claims;
using DataContract.ResponseType;

namespace BusinessLib.Account
{
    public class AccountService : IAccountService
    {
        private readonly DbContextProvider _dbContext;
        private readonly IConfiguration _configuration;
        public AccountService(DbContextProvider dbContext, IConfiguration configuration)
        {
            _dbContext = dbContext;
            _configuration = configuration;
        }

        public Response<bool> AddUpdateUser(UserDto user)
        {
            Response<bool> response = new Response<bool>();
            var _user = new Users();
            try
            {
                var existUser = _dbContext.Users.FirstOrDefault(u => u.UserName == user.UserName && u.IsActive == true);
                if (existUser == null)
                {
                    byte[] passwordHash, passwordSalt;
                    CreatePasswordHash(user.Password, out passwordHash, out passwordSalt);
                    _user.PasswordHash = passwordHash;
                    _user.PasswordSalt = passwordSalt;
                    _user.UserName = user.UserName;
                    _user.FName = user.FName;
                    _user.LName = user.LName;
                    _user.IsActive = true;
                    _user.CreatedBy = 1;
                    _user.CreatedOn = DateTime.UtcNow;
                    _user.EmailAddress = user.EmailAddress;
                    _dbContext.Users.Add(_user);
                }
                _dbContext.SaveChanges();
                response.Success = true;
                response.Message = "Operation successful";
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }
            return response;
        }
        private static void CreatePasswordHash(string password, out byte[] passwordHash, out byte[] passwordSalt)
        {
            try
            {
                if (password == null) throw new ArgumentNullException("password");
                if (string.IsNullOrWhiteSpace(password)) throw new ArgumentException("Value cannot be empty or whitespace only string", "password");

                using (var hmac = new System.Security.Cryptography.HMACSHA512())
                {
                    passwordSalt = hmac.Key;
                    passwordHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        private byte[] ComputeHash(string password, byte[] salt)
        {

            using (var sha256 = SHA256.Create())
            {
                var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password).Concat(salt).ToArray());
                return hashedBytes;
            }
        }

        public AuthenticateResultModel Authenticate(string username, string password)
        {
            var user = ValidateUser(username, password);

            if (user == null)
            {

                return null;
            }
            var accessToken = GenerateAccessToken(user);

            var resultModel = new AuthenticateResultModel
            {
                AccessToken = accessToken,
                EncryptedAccessToken = null,
                ExpireInSeconds = 300,
                UserId = user.UserId,
                Users = null
            };
            return resultModel;
        }

        private string GenerateAccessToken(Users user)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new List<Claim>
    {
        new Claim(ClaimTypes.NameIdentifier, user.UserId.ToString()),
        new Claim(ClaimTypes.Name, user.UserName),
        new Claim("userReference", user.UserId.ToString()),

    };

            var token = new JwtSecurityToken(
                issuer: _configuration["Jwt:Issuer"],
                audience: _configuration["Jwt:Issuer"],
                claims: claims,
                expires: DateTime.Now.AddMinutes(120),
                signingCredentials: credentials
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        public Users ValidateUser(string username, string password)
        {

            var user = _dbContext.Users.SingleOrDefault(x => x.UserName == username || x.EmailAddress == username && x.IsActive == true);
            if (user == null)
            {
                return null;
            }
            var authenticateResultModel = new AuthenticateResultModel();
            var verify = VerifyuserPassword(user, password);
            if (verify == null)
                return null;

            return user;
        }
        private Users VerifyuserPassword(Users user, string Password)
        {
            if (!VerifyPasswordHash(Password, user.PasswordHash, user.PasswordSalt))
            {
                return null;
            }
            else
            {
                return user;
            }
        }
        private static bool VerifyPasswordHash(string password, byte[] storedHash, byte[] storedSalt)
        {
            try
            {
                using (var hmac = new System.Security.Cryptography.HMACSHA512(storedSalt))
                {
                    var computedHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
                    for (int i = 0; i < computedHash.Length; i++)
                    {
                        if (computedHash[i] != storedHash[i]) return false;
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public Response<List<BookDto>> GetBooks()
        {
            Response<List<BookDto>> response = new Response<List<BookDto>>();
            try
            {
                List<BookDto> bookDtos = new List<BookDto>();
                var bookslst = _dbContext.Books;
                foreach (var book in bookslst)
                {
                    BookDto bookDto = new BookDto();
                    bookDto.Id = book.Id;
                    bookDto.Title = book.Title;
                    bookDto.Author = book.Author;
                    bookDto.Price = book.Price;
                    bookDto.PublicationYear = book.PublicationYear;
                    bookDto.IsActive = book.IsActive;
                    bookDtos.Add(bookDto);
                }
                response.Data = bookDtos;
                response.Success = true;
                response.Message = "OK";
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = "Books not found.";
            }
            return response;
        }
        public Response<bool> AddUpdateBook(BookDto book)
        {
            Response<bool> response = new Response<bool>();
            try
            {
                var existingBook = _dbContext.Books.FirstOrDefault(x => x.Id == book.Id);

                if (existingBook != null)
                {
                    // Update existing book
                    existingBook.Title = book.Title;
                    existingBook.Price = book.Price;
                    existingBook.Author = book.Author;
                    existingBook.IsActive = book.IsActive;
                    existingBook.ModifiedBy = 1;
                    existingBook.PublicationYear = book.PublicationYear;
                    existingBook.ModifiedOn = DateTime.Now;
                    _dbContext.Books.Update(existingBook);
                }
                else
                {
                    // Add new book
                    var newBook = new Book
                    {
                        Id = book.Id,
                        Title = book.Title,
                        Price = book.Price,
                        Author = book.Author,
                        IsActive = true,
                        CreatedBy = 1,
                        CreatedOn = DateTime.Now,
                        PublicationYear = book.PublicationYear
                    };
                    _dbContext.Books.Add(newBook);
                }
                _dbContext.SaveChanges();
                response.Success = true;
                response.Message = "Operation successful";
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }
            return response;
        }

        public Response<bool> DeleteBook(int id)
        {
            Response<bool> response = new Response<bool>();
            try
            {
                var existingBook = _dbContext.Books.FirstOrDefault(x => x.Id == id);
                if (existingBook != null)
                {
                    _dbContext.Books.Remove(existingBook);
                    _dbContext.SaveChanges();
                    response.Success = true;
                    response.Message = "Book deleted successfully.";
                }
                else
                {
                    response.Success = false;
                    response.Message = "Book not found.";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = $"An error occurred: {ex.Message}";
            }
            return response;
        }
    }
}
