﻿using DataContract.Dto;
using DataContract.ResponseType;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLib.Account
{
    public interface IAccountService
    {
        Response<bool> AddUpdateBook(BookDto book);
        Response<bool> AddUpdateUser(UserDto user);
        AuthenticateResultModel Authenticate(string username, string password);
        Response<bool> DeleteBook(int id);
        Response<List<BookDto>> GetBooks();
    }
}
