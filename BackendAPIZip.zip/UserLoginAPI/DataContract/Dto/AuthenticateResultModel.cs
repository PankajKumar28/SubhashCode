﻿using DataLib.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataContract.Dto
{
    public class AuthenticateResultModel
    {
        public string AccessToken { get; set; }
        public string EncryptedAccessToken { get; set; }
        public double ExpireInSeconds { get; set; }
        public long UserId { get; set; }

        public List<Users> Users { get; set; }
    }
}
