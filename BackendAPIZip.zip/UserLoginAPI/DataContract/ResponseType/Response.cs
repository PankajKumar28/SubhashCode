﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataContract.ResponseType
{
    public class Response
    {
        public string Message { get; set; }
        public bool Success { get; set; } = true;
        public string Status { get; set; }
    }
    public sealed class Response<TReturn> : Response
    {
        public TReturn Data { get; set; }
    }
}
