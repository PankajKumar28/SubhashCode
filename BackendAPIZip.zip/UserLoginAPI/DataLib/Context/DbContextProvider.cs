﻿using DataLib.Entity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLib.Context
{
    public class DbContextProvider : DbContext
    {
        public DbContextProvider()
        {

        }
        public DbContextProvider(DbContextOptions<DbContextProvider> options) : base(options)
        {
        }
        public DbSet<Users> Users { get; set; }
        public DbSet<Book> Books { get; set; }
    }
}
