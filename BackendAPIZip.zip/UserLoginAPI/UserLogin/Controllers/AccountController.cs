﻿using BusinessLib.Account;
using DataContract.Dto;
using DataContract.ResponseType;
using DataLib.Entity;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace UserLogin.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly IAccountService _accountService;
        public AccountController(IAccountService accountService)
        {
            _accountService = accountService;

        }
        /// <summary>
        /// Login
        /// </summary>
        /// <param name="login"></param>
        /// <returns></returns>
        [HttpPost("Login")]
        public IActionResult Login([FromBody] LoginModel login)
        {
            var result = _accountService.Authenticate(login.UserNameOrEmailAddress, login.Password);

            if (result == null)
            {
                // Authentication failed
                return Unauthorized();
            }
            return Ok(result);
        }
        /// <summary>
        /// AddUpdateUser
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        [HttpPost("AddUpdateUser")]
        public Response<bool> AddUpdateUser(UserDto user)
        {
            return _accountService.AddUpdateUser(user);
        }
        /// <summary>
        /// GetBooks
        /// </summary>
        /// <returns></returns>
        [HttpGet("GetBooks")]
        public Response<List<BookDto>> GetBooks()
        {
            return _accountService.GetBooks();
        }
        /// <summary>
        /// AddUpdateBook
        /// </summary>
        /// <param name="book"></param>
        /// <returns></returns>
        [HttpPost("AddUpdateBook")]
        public Response<bool> AddUpdateBook(BookDto book)
        {
            return _accountService.AddUpdateBook(book);
        }
        /// <summary>
        /// deleteBook
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete("deleteBook")]
        public Response<bool> DeleteBook(int id)
        {
            return _accountService.DeleteBook(id);
        }
    }
}
