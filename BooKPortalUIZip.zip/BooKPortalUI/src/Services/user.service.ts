import { Inject, Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root', // This makes the service available in the root injector
})

export class UserService {
  ///https://localhost:44301/api/Account/AddUpdateUser
  http: HttpClient;
  apiBaseUrl: string = "";
  constructor(@Inject(HttpClient) HttpClient: HttpClient) {
    this.http = HttpClient;
  }

  login(data: any): Observable<any> {
    return this.http.post(`https://localhost:44301/api/Account/Login`, data);
  }
  registerUser(data: any): Observable<any> {
    return this.http.post(`https://localhost:44301/api/Account/AddUpdateUser`, data);
  }

  getBooksData(): Observable<any> {
    return this.http.get(`https://localhost:44301/api/Account/GetBooks`);
  }

  addUpdateBook(data: any): Observable<any> {
    return this.http.post(`https://localhost:44301/api/Account/AddUpdateBook`, data);
  }

  deleteBook(Id: any): Observable<any> {
    return this.http.delete(`https://localhost:44301/api/Account/DeleteBook?Id=` + Id);
  }

}
