import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/Services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  isChangePassowrd: boolean = true;
  isforgetPassword: boolean = true;
  userInfo: any = {};
  tokenKey: string = "tokenKey";
  isLogin: boolean = true;
  constructor(private route: Router, private service: UserService) { }

  ngOnInit(): void {
  }

  onSubmit(userInfo: any) {
    this.service.login(userInfo).subscribe((response: any) => {
      if (response) {
        localStorage.setItem(this.tokenKey, JSON.stringify(response.accessToken));
        if (response.accessToken && response.accessToken != null) {
          alert('Login successful!');
          this.route.navigate(['/app/user'])
        }
      }
      else {
        console.log(response.message);
      }
    })
  }
}
