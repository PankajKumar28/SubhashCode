import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/Services/user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {

  registrationInfo: any = {};
  constructor(private service: UserService, private route: Router) { }

  ngOnInit(): void {
  }

  addingNewUser(data: any) {
    debugger
    this.service.registerUser(data).subscribe((response: any) => {
      debugger
      if (response.success == true) {
        alert('Registration successful!');
        this.route.navigate(['/account/login'])
      }
      else {
        console.log(response.message);
      }
    });
  }
}
