import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserComponent } from './user/user.component';
import { CommonModule } from '@angular/common';
import { AuthGuard } from 'src/Services/Model/auth-guard.guard';


const routes: Routes = [
  { path: 'user', component: UserComponent, canActivate: [AuthGuard] },

];
@NgModule({
  declarations: [],
  imports: [RouterModule.forChild(routes),
    CommonModule
  ]
})
export class AppRoutingModule { }
