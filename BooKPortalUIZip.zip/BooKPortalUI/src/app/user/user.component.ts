import { Component } from '@angular/core';
import { cloneDeep } from 'lodash';
import { ToastrService } from 'ngx-toastr';
import { UserService } from 'src/Services/user.service';


@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent {
  title: string = "";
  tempData: Array<any> = [];
  minPublicationYear = 1900;
  maxPublicationYear = new Date().getFullYear();
  userInfo = {
    id: 0,
    title: '',
    author: '',
    publicationYear: null,
    price: null
  };
  booksList: Array<any> = [];

  constructor(private toastr: ToastrService, private service: UserService) {

  }

  ngOnInit(): void {
    this.getBooksData();
  }

  getBooksData() {
    this.service.getBooksData().subscribe((response: any) => {
      if (response.success == true) {
        this.booksList = cloneDeep(response.data);
        this.tempData = cloneDeep(response.data);
      }
    })
  }

  onSubmit(data: any) {
    this.service.addUpdateBook(data).subscribe((response: any) => {
      if (response.success == true) {
        alert(response.message)
        this.getBooksData();
        // let existIndex = this.booksList.findIndex((x => x.id == data.id));
        // if (existIndex == -1) {
        //   alert('Data  successful!');
        //   this.booksList.push(data);
        // }
        // else if (existIndex > -1) {
        //   alert('Login successful!');
        //   this.booksList[existIndex] = data;
        // }
      }
    })
  }

  deleteBook(Id: any, index: any) {
    this.service.deleteBook(Id).subscribe((response: any) => {
      if (response.success == true) {
        this.booksList.splice(index, 1)
      }
    })
  }

  logout() {
    localStorage.clear();
  }

  checkYear(year: any): boolean {
    if (year && !isNaN(year)) {
      const parsedYear = parseInt(year, 10);
      const currentYear = new Date().getFullYear();
      const minYear = 1900;
      const maxYear = currentYear + 10;
      return Number.isInteger(parsedYear) && parsedYear >= minYear && parsedYear <= maxYear;
    }
    return false;
  }

  openPopUp(data: any) {
    if (data != 'Add') {
      this.userInfo = {
        id: data.id,
        title: data.title,
        author: data.author,
        publicationYear: data.publicationYear,
        price: data.price
      };
    }
    else {
      this.userInfo = {
        id: 0,
        title: '',
        author: '',
        publicationYear: null,
        price: null
      };
    }
  }

  close() {
    this.userInfo = {
      id: 0,
      title: '',
      author: '',
      publicationYear: null,
      price: null
    };
  }
}
