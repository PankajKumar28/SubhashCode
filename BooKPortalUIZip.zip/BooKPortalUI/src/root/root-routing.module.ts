import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';




const routes: Routes = [
  {
    path: '', redirectTo: 'account/login', pathMatch: 'full'
  },
  {
    path: "app",
    loadChildren: () => import('../app/app.module').then(m => m.AppModule),
  },
  {
    path: "account",
    loadChildren: () => import('../account/account.module').then(m => m.AccountModule)
  },

  { path: '**', redirectTo: '/notfound', pathMatch: 'full' }
]


@NgModule({
  declarations: [],
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [RouterModule]
})

export class RootRoutingModule { }
