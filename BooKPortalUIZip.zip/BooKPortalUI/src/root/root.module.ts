import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RootComponent } from './root/root.component';
import { BrowserModule } from '@angular/platform-browser';
import { RootRoutingModule } from './root-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';


@NgModule({
  declarations: [
    RootComponent
  ],
  imports: [
    CommonModule, BrowserModule, FormsModule, ReactiveFormsModule, RootRoutingModule, BrowserAnimationsModule, HttpClientModule,ToastrModule.forRoot() 
  ],
  providers: [],
  exports: [],
  bootstrap: [RootComponent]
})
export class RootModule { }
